package com.asielose172.mypersonalshopper

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityFerDemanatBinding

class FerDemanatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFerDemanatBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFerDemanatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATFerDemanatBack.setOnClickListener {
            finish()
        }
    }
}