package com.asielose172.mypersonalshopper.myshopperOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.R
import com.asielose172.mypersonalshopper.databinding.ActivityChatBinding
import com.asielose172.mypersonalshopper.databinding.ActivityMyShopperBinding

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATMyShopperChatBack.setOnClickListener {
            finish()
        }
    }
}