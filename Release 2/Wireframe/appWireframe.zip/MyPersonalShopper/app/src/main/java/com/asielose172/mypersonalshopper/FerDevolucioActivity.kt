package com.asielose172.mypersonalshopper

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityFerDemanatBinding
import com.asielose172.mypersonalshopper.databinding.ActivityFerDevolucioBinding

class FerDevolucioActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFerDevolucioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFerDevolucioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATFerDevolucioBack.setOnClickListener {
            finish()
        }
    }
}