package com.asielose172.mypersonalshopper.profileOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityEstilBinding

class EstilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEstilBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEstilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATProfileBackOption1.setOnClickListener {
            finish()
        }
    }
}