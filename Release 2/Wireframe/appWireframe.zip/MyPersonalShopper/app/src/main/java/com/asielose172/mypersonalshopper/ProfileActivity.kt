package com.asielose172.mypersonalshopper

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageButton
import androidx.recyclerview.widget.RecyclerView
import com.asielose172.mypersonalshopper.databinding.ActivityProfileBinding
import com.asielose172.mypersonalshopper.profileOptions.CanviPasswordActivity
import com.asielose172.mypersonalshopper.profileOptions.DadesActivity
import com.asielose172.mypersonalshopper.profileOptions.EstilActivity
import com.asielose172.mypersonalshopper.profileOptions.MetodesPagamentActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATProfileBack.setOnClickListener {
            finish()
        }

        binding.bATProfileOption1.setOnClickListener {
            val intent = Intent(this, EstilActivity::class.java)
            startActivity(intent)
        }

        binding.bATProfileOption2.setOnClickListener {
            val intent = Intent(this, DadesActivity::class.java)
            startActivity(intent)
        }

        binding.bATProfileOption3.setOnClickListener {
            val intent = Intent(this, CanviPasswordActivity::class.java)
            startActivity(intent)
        }

        binding.bATProfileOption4.setOnClickListener {
            val intent = Intent(this, MetodesPagamentActivity::class.java)
            startActivity(intent)
        }

        binding.bATProfileOption5.setOnClickListener {
            val dialog = Dialog(this)
            dialog.setContentView(R.layout.dialog_profile_option_5)

            val window = dialog.window
            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(window?.attributes)
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
            window?.attributes = layoutParams
            window?.setBackgroundDrawableResource(R.drawable.dialog_shape)

            dialog.show()

            val ibATProfileCloseOption5: ImageButton = dialog.findViewById(R.id.ibATProfileCloseOption5)

            ibATProfileCloseOption5.setOnClickListener {
                dialog.dismiss()
            }
        }
    }
}