package com.asielose172.mypersonalshopper

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityMyShopperBinding
import com.asielose172.mypersonalshopper.myshopperOptions.CanviPersonalShopperActivity
import com.asielose172.mypersonalshopper.myshopperOptions.ChatActivity

class MyShopperActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyShopperBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyShopperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATMyShopperBack.setOnClickListener {
            finish()
        }

        binding.bATMyShopperOption1.setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            startActivity(intent)
        }

        binding.bATMyShopperOption2.setOnClickListener {
            val intent = Intent(this, CanviPersonalShopperActivity::class.java)
            startActivity(intent)
        }
    }
}