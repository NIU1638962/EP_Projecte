package com.asielose172.mypersonalshopper.profileOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityDadesBinding

class DadesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDadesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDadesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATProfileBackOption2.setOnClickListener {
            finish()
        }
    }
}