package com.asielose172.mypersonalshopper.profileOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityCanviPasswordBinding

class CanviPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCanviPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanviPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATProfileBackOption3.setOnClickListener {
            finish()
        }
    }
}