package com.asielose172.mypersonalshopper.myshopperOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityCanviPersonalShopperBinding

class CanviPersonalShopperActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCanviPersonalShopperBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanviPersonalShopperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATMyShopperCanviPSBack.setOnClickListener {
            finish()
        }
    }
}