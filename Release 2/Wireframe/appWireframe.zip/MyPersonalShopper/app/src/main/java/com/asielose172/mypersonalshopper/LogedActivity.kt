package com.asielose172.mypersonalshopper

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityLogedBinding

class LogedActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initButtons()
    }

    private fun initButtons() {
        binding.ibATLogedBack.setOnClickListener {
            finish()
        }

        binding.ibATLogedPerfil.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        binding.ibATLogedMyShopper.setOnClickListener {
            val intent = Intent(this, MyShopperActivity::class.java)
            startActivity(intent)
        }

        binding.ibATLogedDevolucio.setOnClickListener {
            val intent = Intent(this, FerDevolucioActivity::class.java)
            startActivity(intent)
        }

        binding.ibATLogedDemanat.setOnClickListener {
            val intent = Intent(this, FerDemanatActivity::class.java)
            startActivity(intent)
        }
    }
}