package com.asielose172.mypersonalshopper.profileOptions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asielose172.mypersonalshopper.databinding.ActivityMetodesPagamentBinding

class MetodesPagamentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMetodesPagamentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMetodesPagamentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ibATProfileBackOption4.setOnClickListener {
            finish()
        }
    }
}